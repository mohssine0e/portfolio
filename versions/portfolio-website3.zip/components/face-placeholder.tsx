'use client'

import { motion } from 'framer-motion'

interface FacePlaceholderProps {
  size?: 'hero' | 'header'
}

export function FacePlaceholder({ size = 'hero' }: FacePlaceholderProps) {
  const isHero = size === 'hero'
  
  const sizeClasses = isHero
    ? 'w-48 h-48'
    : 'w-12 h-12'
  
  const glowClasses = isHero
    ? 'w-60 h-60'
    : 'w-20 h-20'

  return (
    <motion.div
      layoutId="face-avatar"
      className={`relative rounded-full overflow-hidden border border-[#10b981]/40 flex-shrink-0 ${sizeClasses}`}
    >
      {/* Glow background */}
      <motion.div
        className={`absolute -inset-4 rounded-full blur-xl opacity-50 ${glowClasses}`}
        style={{
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.3) 0%, transparent 100%)',
        }}
      />

      {/* Avatar content */}
      <div className="relative w-full h-full bg-gradient-to-br from-[#10b981]/10 to-[#06b6d4]/10 flex items-center justify-center">
        <svg
          className={`text-[#10b981]/50 ${isHero ? 'w-16 h-16' : 'w-5 h-5'}`}
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
        </svg>
      </div>

      {/* Status badge - hero only */}
      {isHero && (
        <motion.div
          className="absolute -bottom-3 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-xs font-mono text-[#10b981] bg-[#10b981]/15 border border-[#10b981]/30"
          animate={{ opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          [ONLINE]
        </motion.div>
      )}
    </motion.div>
  )
}
