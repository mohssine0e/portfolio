'use client'

import { motion, useScroll, useTransform } from 'framer-motion'
import { useRef, useEffect, useState } from 'react'

export function FacePlaceholder() {
  const containerRef = useRef(null)
  const { scrollY } = useScroll()
  const [heroHeight, setHeroHeight] = useState(0)

  useEffect(() => {
    const heroElement = document.querySelector('#hero')
    if (heroElement) {
      setHeroHeight(heroElement.offsetHeight)
    }
  }, [])

  // Position: starts at left-8 in hero, moves to header as you scroll
  // When scroll < heroHeight: stays in hero area (left-8, top-1/2)
  // When scroll > heroHeight: moves to fixed header position
  const leftPosition = useTransform(
    scrollY,
    [0, heroHeight, heroHeight + 100],
    ['2rem', '2rem', '1.5rem'] // Adjust final value as needed
  )

  // Size: 200x200 in hero, shrinks to 50x50 in header
  const size = useTransform(
    scrollY,
    [0, heroHeight, heroHeight + 100],
    [200, 200, 50]
  )

  // Top position: centered in hero, then fixed at top
  const topPosition = useTransform(
    scrollY,
    [0, heroHeight, heroHeight + 100],
    ['50%', '50%', '1.5rem']
  )

  // Opacity glow size
  const glowSize = useTransform(
    scrollY,
    [0, heroHeight, heroHeight + 100],
    [240, 240, 70]
  )

  // Rotate 360 degrees as user scrolls past hero
  const rotate = useTransform(scrollY, [0, heroHeight + 200], [0, 360])

  // Determine if in header or hero based on scroll
  const position = useTransform(scrollY, (value) => {
    return value > heroHeight ? 'fixed' : 'fixed'
  })

  return (
    <motion.div
      ref={containerRef}
      className="z-50 hidden lg:block"
      style={{
        position: 'fixed',
        left: leftPosition,
        top: topPosition,
        rotate: rotate,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      {/* Outer glow ring - scales with size */}
      <motion.div
        className="absolute rounded-full pointer-events-none"
        style={{
          background: 'radial-gradient(circle, rgba(16, 185, 129, 0.3) 0%, rgba(16, 185, 129, 0) 100%)',
          width: glowSize,
          height: glowSize,
          filter: 'blur(20px)',
        }}
        animate={{
          boxShadow: [
            '0 0 20px rgba(16, 185, 129, 0.3)',
            '0 0 40px rgba(16, 185, 129, 0.5)',
            '0 0 20px rgba(16, 185, 129, 0.3)',
          ],
        }}
        transition={{ duration: 3, repeat: Infinity }}
      />

      {/* Avatar container - main size element */}
      <motion.div
        className="relative rounded-full border-2 border-[#10b981]/50 overflow-hidden bg-gradient-to-br from-[#10b981]/10 to-[#06b6d4]/10 backdrop-blur-sm flex-shrink-0"
        style={{
          width: size,
          height: size,
        }}
      >
        {/* Placeholder image - user will replace with actual photo */}
        <div className="w-full h-full bg-gradient-to-br from-[#10b981]/20 via-[#0a0e27] to-[#06b6d4]/20 flex items-center justify-center">
          {/* Placeholder SVG - scales automatically */}
          <svg
            className="w-1/2 h-1/2 text-[#10b981]/40"
            fill="currentColor"
            viewBox="0 0 24 24"
          >
            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
          </svg>
          <motion.span
            className="absolute text-center text-[#10b981]/50 font-mono"
            style={{
              fontSize: useTransform(scrollY, [0, heroHeight + 100], ['12px', '8px']),
              bottom: useTransform(scrollY, [0, heroHeight + 100], ['1rem', '0.3rem']),
            }}
          >
            PHOTO
          </motion.span>
        </div>

        {/* Scan line effect overlay */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-b from-transparent via-white to-transparent"
          style={{ opacity: 0.05 }}
          animate={{
            y: ['0%', '100%'],
          }}
          transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
        />

        {/* Border glow */}
        <motion.div
          className="absolute inset-0 rounded-full border-2 border-transparent"
          style={{
            boxShadow: 'inset 0 0 20px rgba(16, 185, 129, 0.2)',
          }}
          animate={{
            boxShadow: [
              'inset 0 0 20px rgba(16, 185, 129, 0.1)',
              'inset 0 0 30px rgba(16, 185, 129, 0.3)',
              'inset 0 0 20px rgba(16, 185, 129, 0.1)',
            ],
          }}
          transition={{ duration: 3, repeat: Infinity }}
        />
      </motion.div>

      {/* Status indicator - only shows in hero */}
      <motion.div
        className="absolute font-mono text-[#10b981]/70 bg-[#10b981]/10 border border-[#10b981]/30 rounded-full"
        style={{
          opacity: useTransform(
            scrollY,
            [0, heroHeight - 200, heroHeight],
            [1, 0.7, 0]
          ),
          padding: useTransform(
            scrollY,
            [0, heroHeight + 100],
            ['0.5rem 0.75rem', '0.25rem 0.5rem']
          ),
          fontSize: useTransform(
            scrollY,
            [0, heroHeight + 100],
            ['12px', '8px']
          ),
          bottom: useTransform(
            scrollY,
            [0, heroHeight + 100],
            ['-1rem', '-0.5rem']
          ),
          left: '50%',
          transform: 'translateX(-50%)',
          whiteSpace: 'nowrap',
        }}
        animate={{ opacity: [0.5, 1, 0.5] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        [ONLINE]
      </motion.div>
    </motion.div>
  )
}
